
package proyecto1;
import java.util.*;

public class Proyecto1 {

    
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        Alumno alumno = new Alumno();
        alumno.setNombre("Juan");
        alumno.setApellido("Vindas");
        alumno.setCarnet("4454845");
        Curso curso = new Curso();
        curso.setNombre("Progra1");
        curso.setProfesor("Jirafales");
        curso.setUniversidad("UPI");
        curso.registrar(alumno);
        System.out.println(curso.toString());
    }
    
}
