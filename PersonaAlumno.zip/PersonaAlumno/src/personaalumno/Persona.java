
package personaalumno;

public class Persona {
    private String nombre;
    private String apellido1;
    private String cedula;
    private int annoDeNacimiento;
    private int edad;

    public Persona(String nombre, String apellido1, String cedula, int edad) {
        this.nombre = nombre;
        this.apellido1 = apellido1;
        this.cedula = cedula;
        this.edad = edad;
        this.calcularAnnoDeNacimiento();
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido1() {
        return apellido1;
    }

    public void setApellido1(String apellido1) {
        this.apellido1 = apellido1;
    }

    public String getCedula() {
        return cedula;
    }

    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    public int getAnnoDeNacimiento() {
        return annoDeNacimiento;
    }

    public void setAnnoDeNacimiento(int annoDeNacimiento) {
        this.annoDeNacimiento = annoDeNacimiento;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    @Override
    public String toString() {
        return "Nombre: " + nombre + "\nApellido: " + apellido1 +
                "\nEdad: " + edad + "\nAño de nacimiento: " + annoDeNacimiento +
                "\nCédula: " + cedula;
    }
    
    public void calcularAnnoDeNacimiento(){
        setAnnoDeNacimiento(2017 - edad);
    }
    
    
}
