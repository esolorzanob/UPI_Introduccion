package personaalumno;

import java.lang.reflect.Array;
import java.util.*;

public class PersonaAlumno {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        Alumno alumno1;
        Curso curso1;
        ArrayList arreglo = new ArrayList();
        do {
            System.out.println("Programa de registro");
            System.out.println("1. Crear Alumno");
            System.out.println("2. Crear Curso");
            System.out.println("3. Registrar Curso");
            System.out.println("Por favor digite una opcion");
            int opcion = teclado.nextInt();
            teclado.nextLine();
            if (opcion == 1) {
                System.out.println("Digite el nombre");
                String nombre = teclado.nextLine();
                System.out.println("Digite el apellido");
                String apellido = teclado.nextLine();
                System.out.println("Digite la edad");
                int edad = teclado.nextInt();
                teclado.nextLine();
                System.out.println("Digite la cedula");
                String cedula = teclado.nextLine();
                Persona persona1 = new Persona(nombre, apellido, cedula, edad);
                alumno1 = new Alumno(persona1);
                arreglo.add(alumno1);
            } else if (opcion == 2) {
                System.out.println("Digite el nombre del curso");
                String nombreDelCurso = teclado.nextLine();
                System.out.println("Digite el nombre del profesor");
                String nombreDelProfesor = teclado.nextLine();
                System.out.println("Digite el nombre de la Universidad");
                String nombreDeLaUniversidad = teclado.nextLine();
                curso1 = new Curso(nombreDelCurso, nombreDelProfesor, nombreDeLaUniversidad);
                arreglo.add(curso1);
            } else {
                
                ((Alumno)arreglo.get(0)).registrarCurso((Curso)arreglo.get(1));
                System.out.println(((Alumno)arreglo.get(0)).toString());
            }

        } while (true);

    }

}
