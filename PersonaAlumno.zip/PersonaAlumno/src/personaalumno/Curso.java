
package personaalumno;

public class Curso {
   private String nombre, profesor, universidad;

    public Curso(String nombre, String profesor, String universidad) {
        this.nombre = nombre;
        this.profesor = profesor;
        this.universidad = universidad;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getProfesor() {
        return profesor;
    }

    public void setProfesor(String profesor) {
        this.profesor = profesor;
    }

    public String getUniversidad() {
        return universidad;
    }

    public void setUniversidad(String universidad) {
        this.universidad = universidad;
    }

    @Override
    public String toString() {
        return "Curso \n\tNombre: " + nombre + "\n\tProfesor: " + profesor
                + "\n\tUniversidad: " + universidad;
    }
   
}
