
package personaalumno;
import java.util.*;

public class Alumno {
    private Persona persona;
    private ArrayList cursos = new ArrayList();

    public Alumno(Persona persona) {
        this.persona = persona;        
    }

    public Persona getPersona() {
        return persona;
    }

    public void setPersona(Persona persona) {
        this.persona = persona;
    }

    public ArrayList getCursos() {
        return cursos;
    }

    public void setCursos(ArrayList cursos) {
        this.cursos = cursos;
    }   

    @Override
    public String toString() {
        String listaDeCursos = "";
        for (int i = 0; i < cursos.size(); i++) {
            listaDeCursos += ((Curso)cursos.get(i)).toString();
        }
        return persona.toString() + "\nMatriculado en\n" + listaDeCursos;
    }
    
    public void registrarCurso(Curso curso){
        cursos.add(curso);
    }
    
}
